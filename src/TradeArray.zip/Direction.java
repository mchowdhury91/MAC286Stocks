
public enum Direction {
	LONG, SHORT;
}
